
# Stock Prediction
#### This project introduces common techniques to manipulate time series and make predictions.
### Goal: To predict the closing price in the next five trading days starting February 1st, 2019.


The data is a sample from the historical end of day (EOD) stock prices for all US public companies excluding over the counter (OTC) stocks. Open, high, low, close, volume, as well as prices adjusted for splits and dividends, are included. Includes delisted securities over the 5 year time period. History is daily back to January 1st, 2013.
https://about.intrinio.com/bulk-financial-data-downloads

### Cleaning data
1. Import libraries for our analysis. 
2. Define the mean average percentage error (MAPE), this will be our error metric.


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

from sklearn.metrics import r2_score, median_absolute_error, mean_absolute_error
from sklearn.metrics import median_absolute_error, mean_squared_error, mean_squared_log_error

from scipy.optimize import minimize
import statsmodels.tsa.api as smt
import statsmodels.api as sm

from tqdm import tqdm_notebook

from itertools import product

def mean_absolute_percentage_error(y_true, y_pred):
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

import warnings
warnings.filterwarnings('ignore')

%matplotlib inline
```


```python
#import our dataset
DATAPATH = 'data/stock_prices_sample.csv'
```


```python
data = pd.read_csv(DATAPATH, index_col=['DATE'], parse_dates=['DATE'])
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SECURITY_ID</th>
      <th>TICKER</th>
      <th>FIGI</th>
      <th>TYPE</th>
      <th>FREQUENCY</th>
      <th>OPEN</th>
      <th>HIGH</th>
      <th>LOW</th>
      <th>CLOSE</th>
      <th>VOLUME</th>
      <th>ADJ_OPEN</th>
      <th>ADJ_HIGH</th>
      <th>ADJ_LOW</th>
      <th>ADJ_CLOSE</th>
      <th>ADJ_VOLUME</th>
      <th>ADJ_FACTOR</th>
      <th>EX_DIVIDEND</th>
      <th>SPLIT_RATIO</th>
    </tr>
    <tr>
      <th>DATE</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2013-01-04</th>
      <td>3102</td>
      <td>GEF</td>
      <td>BBG000BLFQH8</td>
      <td>EOD</td>
      <td>daily</td>
      <td>46.31</td>
      <td>47.6198</td>
      <td>46.2300</td>
      <td>47.3700</td>
      <td>248000</td>
      <td>38.517220</td>
      <td>39.606614</td>
      <td>38.450681</td>
      <td>39.398849</td>
      <td>248000</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2013-01-03</th>
      <td>3102</td>
      <td>GEF</td>
      <td>BBG000BLFQH8</td>
      <td>EOD</td>
      <td>daily</td>
      <td>46.43</td>
      <td>46.5200</td>
      <td>46.1400</td>
      <td>46.4800</td>
      <td>131300</td>
      <td>38.617027</td>
      <td>38.691882</td>
      <td>38.375826</td>
      <td>38.658613</td>
      <td>131300</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2013-01-02</th>
      <td>3102</td>
      <td>GEF</td>
      <td>BBG000BLFQH8</td>
      <td>EOD</td>
      <td>daily</td>
      <td>45.38</td>
      <td>46.5400</td>
      <td>45.1600</td>
      <td>46.4100</td>
      <td>184900</td>
      <td>37.743715</td>
      <td>38.708516</td>
      <td>37.560735</td>
      <td>38.600392</td>
      <td>184900</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-06-05</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>Intraday</td>
      <td>daily</td>
      <td>18.86</td>
      <td>18.9100</td>
      <td>18.8700</td>
      <td>18.8700</td>
      <td>10000</td>
      <td>18.860000</td>
      <td>18.910000</td>
      <td>18.870000</td>
      <td>18.870000</td>
      <td>10000</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-06-04</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.86</td>
      <td>18.8900</td>
      <td>18.7900</td>
      <td>18.8100</td>
      <td>39095</td>
      <td>18.860000</td>
      <td>18.890000</td>
      <td>18.790000</td>
      <td>18.810000</td>
      <td>39095</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-06-01</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.58</td>
      <td>18.7600</td>
      <td>18.5800</td>
      <td>18.7400</td>
      <td>17468</td>
      <td>18.580000</td>
      <td>18.760000</td>
      <td>18.580000</td>
      <td>18.740000</td>
      <td>17468</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-31</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.52</td>
      <td>18.5200</td>
      <td>18.3012</td>
      <td>18.4900</td>
      <td>22384</td>
      <td>18.520000</td>
      <td>18.520000</td>
      <td>18.301200</td>
      <td>18.490000</td>
      <td>22384</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-30</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.47</td>
      <td>18.6780</td>
      <td>18.4700</td>
      <td>18.6500</td>
      <td>22633</td>
      <td>18.470000</td>
      <td>18.678000</td>
      <td>18.470000</td>
      <td>18.650000</td>
      <td>22633</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-29</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.51</td>
      <td>18.5100</td>
      <td>18.1500</td>
      <td>18.2562</td>
      <td>67412</td>
      <td>18.510000</td>
      <td>18.510000</td>
      <td>18.150000</td>
      <td>18.256200</td>
      <td>67412</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-25</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.76</td>
      <td>18.8800</td>
      <td>18.7600</td>
      <td>18.8420</td>
      <td>8775</td>
      <td>18.760000</td>
      <td>18.880000</td>
      <td>18.760000</td>
      <td>18.842000</td>
      <td>8775</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



###### Here we have few entries that are different stock than the New Germany Fund (GF). Also, we have an entry of intraday information, but we only want end of day (EOD) information.


```python
data.shape
```




    (999, 18)




```python
data.dtypes
```




    SECURITY_ID      int64
    TICKER          object
    FIGI            object
    TYPE            object
    FREQUENCY       object
    OPEN           float64
    HIGH           float64
    LOW            float64
    CLOSE          float64
    VOLUME           int64
    ADJ_OPEN       float64
    ADJ_HIGH       float64
    ADJ_LOW        float64
    ADJ_CLOSE      float64
    ADJ_VOLUME       int64
    ADJ_FACTOR     float64
    EX_DIVIDEND    float64
    SPLIT_RATIO      int64
    dtype: object




```python
#Let’s get rid of the unwanted entries:
data = data[data.TICKER != 'GEF']
data = data[data.TYPE != 'Intraday']
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SECURITY_ID</th>
      <th>TICKER</th>
      <th>FIGI</th>
      <th>TYPE</th>
      <th>FREQUENCY</th>
      <th>OPEN</th>
      <th>HIGH</th>
      <th>LOW</th>
      <th>CLOSE</th>
      <th>VOLUME</th>
      <th>ADJ_OPEN</th>
      <th>ADJ_HIGH</th>
      <th>ADJ_LOW</th>
      <th>ADJ_CLOSE</th>
      <th>ADJ_VOLUME</th>
      <th>ADJ_FACTOR</th>
      <th>EX_DIVIDEND</th>
      <th>SPLIT_RATIO</th>
    </tr>
    <tr>
      <th>DATE</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-06-04</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.86</td>
      <td>18.890</td>
      <td>18.7900</td>
      <td>18.8100</td>
      <td>39095</td>
      <td>18.86</td>
      <td>18.890</td>
      <td>18.7900</td>
      <td>18.8100</td>
      <td>39095</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-06-01</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.58</td>
      <td>18.760</td>
      <td>18.5800</td>
      <td>18.7400</td>
      <td>17468</td>
      <td>18.58</td>
      <td>18.760</td>
      <td>18.5800</td>
      <td>18.7400</td>
      <td>17468</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-31</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.52</td>
      <td>18.520</td>
      <td>18.3012</td>
      <td>18.4900</td>
      <td>22384</td>
      <td>18.52</td>
      <td>18.520</td>
      <td>18.3012</td>
      <td>18.4900</td>
      <td>22384</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-30</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.47</td>
      <td>18.678</td>
      <td>18.4700</td>
      <td>18.6500</td>
      <td>22633</td>
      <td>18.47</td>
      <td>18.678</td>
      <td>18.4700</td>
      <td>18.6500</td>
      <td>22633</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2018-05-29</th>
      <td>3119</td>
      <td>GF</td>
      <td>BBG000C3C6S2</td>
      <td>EOD</td>
      <td>daily</td>
      <td>18.51</td>
      <td>18.510</td>
      <td>18.1500</td>
      <td>18.2562</td>
      <td>67412</td>
      <td>18.51</td>
      <td>18.510</td>
      <td>18.1500</td>
      <td>18.2562</td>
      <td>67412</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#remove unwanted columns, focus on the stock’s closing price only:
drop_cols = ['SPLIT_RATIO', 'EX_DIVIDEND', 'ADJ_FACTOR', 'ADJ_VOLUME', 'ADJ_CLOSE', 'ADJ_LOW', 'ADJ_HIGH', 'ADJ_OPEN', 'VOLUME', 'FREQUENCY', 'TYPE', 'FIGI', 'SECURITY_ID']
data.drop(drop_cols, axis=1, inplace=True)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TICKER</th>
      <th>OPEN</th>
      <th>HIGH</th>
      <th>LOW</th>
      <th>CLOSE</th>
    </tr>
    <tr>
      <th>DATE</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2018-06-04</th>
      <td>GF</td>
      <td>18.86</td>
      <td>18.890</td>
      <td>18.7900</td>
      <td>18.8100</td>
    </tr>
    <tr>
      <th>2018-06-01</th>
      <td>GF</td>
      <td>18.58</td>
      <td>18.760</td>
      <td>18.5800</td>
      <td>18.7400</td>
    </tr>
    <tr>
      <th>2018-05-31</th>
      <td>GF</td>
      <td>18.52</td>
      <td>18.520</td>
      <td>18.3012</td>
      <td>18.4900</td>
    </tr>
    <tr>
      <th>2018-05-30</th>
      <td>GF</td>
      <td>18.47</td>
      <td>18.678</td>
      <td>18.4700</td>
      <td>18.6500</td>
    </tr>
    <tr>
      <th>2018-05-29</th>
      <td>GF</td>
      <td>18.51</td>
      <td>18.510</td>
      <td>18.1500</td>
      <td>18.2562</td>
    </tr>
  </tbody>
</table>
</div>



 ### Exploratory data analysis (EDA)


```python
#Let’s see what the closing price looks like:
plt.figure(figsize=(17, 8))
plt.plot(data.CLOSE)
plt.title('Closing price of Germany Fund Inc (GF)')
plt.ylabel('Closing price ($)')
plt.xlabel('Trading day')
plt.grid(False)
plt.show()
```


![png](output_13_0.png)


Clearly, we see that this is not a stationary process, and it is hard to tell if there is some kind of seasonality.

### Moving average
We use the moving average model to smooth our time series. For that, the helper function will run the moving average model on a specified time window and it will plot the result smoothed curve:


```python
def plot_moving_average(series, window, plot_intervals=False, scale=1.96):

    rolling_mean = series.rolling(window=window).mean()
    
    plt.figure(figsize=(17,8))
    plt.title('Moving average\n window size = {}'.format(window))
    plt.plot(rolling_mean, 'g', label='Rolling mean trend')
    
    #Plot confidence intervals for smoothed values
    if plot_intervals:
        mae = mean_absolute_error(series[window:], rolling_mean[window:])
        deviation = np.std(series[window:] - rolling_mean[window:])
        lower_bound = rolling_mean - (mae + scale * deviation)
        upper_bound = rolling_mean + (mae + scale * deviation)
        plt.plot(upper_bound, 'r--', label='Upper bound / Lower bound')
        plt.plot(lower_bound, 'r--')
            
    plt.plot(series[window:], label='Actual values')
    plt.legend(loc='best')
    plt.grid(True)
```

#### Smooth by the previous 5 days (by the work week)



```python
plot_moving_average(data.CLOSE, 5)
```


![png](output_18_0.png)


###### Here we can hardly see a trend, because it is too close to actual curve. Let’s see the result of smoothing by the previous month, and previous quarter.

#### Smooth by the previous month (30 days)


```python

plot_moving_average(data.CLOSE, 30)
```


![png](output_21_0.png)


#### Smooth by previous quarter (90 days)


```python
plot_moving_average(data.CLOSE, 90, plot_intervals=True)
```


![png](output_23_0.png)


##### Trends are easier to spot now. The 30-day and 90-day trend show a downward curve at the end. This might mean that the stock is likely to go down in the following days.

### Exponential smoothing
to see if it can pick up a better trend


```python
def exponential_smoothing(series, alpha):

    result = [series[0]] # first value is same as series
    for n in range(1, len(series)):
        result.append(alpha * series[n] + (1 - alpha) * result[n-1])
    return result
```


```python
def plot_exponential_smoothing(series, alphas):
 
    plt.figure(figsize=(17, 8))
    for alpha in alphas:
        plt.plot(exponential_smoothing(series, alpha), label="Alpha {}".format(alpha))
    plt.plot(series.values, "c", label = "Actual")
    plt.legend(loc="best")
    plt.axis('tight')
    plt.title("Exponential Smoothing")
    plt.grid(True);
```


```python
plot_exponential_smoothing(data.CLOSE, [0.05, 0.3])

#we use 0.05 and 0.3 as values for the smoothing factor. 
#Feel free to try other values and see what the result is.
```


![png](output_28_0.png)


As you can see, an alpha value of 0.05 smoothed the curve while picking up most of the upward and downward trends.

### Double exponential smoothing


```python
def double_exponential_smoothing(series, alpha, beta):

    result = [series[0]]
    for n in range(1, len(series)+1):
        if n == 1:
            level, trend = series[0], series[1] - series[0]
        if n >= len(series): # forecasting
            value = result[-1]
        else:
            value = series[n]
        last_level, level = level, alpha * value + (1 - alpha) * (level + trend)
        trend = beta * (level - last_level) + (1 - beta) * trend
        result.append(level + trend)
    return result
```


```python
def plot_double_exponential_smoothing(series, alphas, betas):
     
    plt.figure(figsize=(17, 8))
    for alpha in alphas:
        for beta in betas:
            plt.plot(double_exponential_smoothing(series, alpha, beta), label="Alpha {}, beta {}".format(alpha, beta))
    plt.plot(series.values, label = "Actual")
    plt.legend(loc="best")
    plt.axis('tight')
    plt.title("Double Exponential Smoothing")
    plt.grid(True)
```


```python
plot_double_exponential_smoothing(data.CLOSE, alphas=[0.9, 0.02], betas=[0.9, 0.02])

```


![png](output_33_0.png)


You may experiment with different alpha and beta combinations to get better looking curves.

### Stationarity
We must turn our series into a stationary process in order to model it. Stationarity refers to the stability of the mean. There is no trend and there is stability of the correlation factor, in other words, structure of the correlation remains constant over time, while in a non stationarity series the trend and correlation dont remain constant. We apply the Dickey-Fuller test to see if it is a stationary process:


```python
def tsplot(y, lags=None, figsize=(12, 7), syle='bmh'):
    
    if not isinstance(y, pd.Series):
        y = pd.Series(y)
        
    with plt.style.context(style='bmh'):
        fig = plt.figure(figsize=figsize)
        layout = (2,2)
        ts_ax = plt.subplot2grid(layout, (0,0), colspan=2)
        acf_ax = plt.subplot2grid(layout, (1,0))
        pacf_ax = plt.subplot2grid(layout, (1,1))
        
        y.plot(ax=ts_ax)
        p_value = sm.tsa.stattools.adfuller(y)[1]
        ts_ax.set_title('Time Series Analysis Plots\n Dickey-Fuller: p={0:.5f}'.format(p_value))
        smt.graphics.plot_acf(y, lags=lags, ax=acf_ax)
        smt.graphics.plot_pacf(y, lags=lags, ax=pacf_ax)
        plt.tight_layout()
        
tsplot(data.CLOSE, lags=30)
```


![png](output_36_0.png)


By using the Dickey-Fuller test, we see the time series is unsurprisingly non-stationary. Also, looking at the autocorrelation plot, we see that it is very high, and it seems that there is no clear seasonality.

Therefore, to get rid of the high autocorrelation and to make the process stationary, we take the first difference. We simply take the time series itself with a lag of one day:


```python
data_diff = data.CLOSE - data.CLOSE.shift(1)

tsplot(data_diff[1:], lags=30)
```


![png](output_38_0.png)


### SARIMA
Seasonal Autoregressive Integrated Moving Average, SARIMA or Seasonal ARIMA, is an extension of ARIMA that explicitly supports univariate time series data with a seasonal component.
It adds three new hyperparameters to specify the autoregression (AR), differencing (I) and moving average (MA) for the seasonal component of the series, as well as an additional parameter for the period of the seasonality. more here: https://machinelearningmastery.com/sarima-for-time-series-forecasting-in-python/

SARIMA, we will define a few parameters and a range of values for other parameters to generate a list of all possible combinations of p, q, d, P, Q, D, s:


```python
#Set initial values and some bounds
ps = range(0, 5)
d = 1
qs = range(0, 5)
Ps = range(0, 5)
D = 1
Qs = range(0, 5)
s = 5

#Create a list with all possible combinations of parameters
parameters = product(ps, qs, Ps, Qs)
parameters_list = list(parameters)
len(parameters_list)
```




    625



We will try each combination (from all 625) and train SARIMA with each so to find the best performing model. (it will take some time)


```python
def optimize_SARIMA(parameters_list, d, D, s):
    
    """    
    Return dataframe with parameters and corresponding AIC
        
        parameters_list - list with (p, q, P, Q) tuples
        d - integration order
        D - seasonal integration order
        s - length of season
    """
    
    
    results = []
    best_aic = float('inf')
    
    for param in tqdm_notebook(parameters_list):
        try: model = sm.tsa.statespace.SARIMAX(data.CLOSE, order=(param[0], d, param[1]),
                                               seasonal_order=(param[2], D, param[3], s)).fit(disp=-1)
        except:
            continue
            
        aic = model.aic
        
        
    #Save best model, AIC and parameters
        if aic < best_aic:
            best_model = model
            best_aic = aic
            best_param = param
        results.append([param, model.aic])
        
    result_table = pd.DataFrame(results)
    result_table.columns = ['parameters', 'aic']
    
    
    #Sort in ascending order, lower AIC is better
    result_table = result_table.sort_values(by='aic', ascending=True).reset_index(drop=True)
    
    return result_table

result_table = optimize_SARIMA(parameters_list, d, D, s)
```


    HBox(children=(IntProgress(value=0, max=625), HTML(value='')))


    



```python
#Set parameters that give the lowest AIC (Akaike Information Criteria)
#AIC deals with both the risk of overfitting and the risk of underfitting.

p, q, P, Q = result_table.parameters[0]

best_model = sm.tsa.statespace.SARIMAX(data.CLOSE, order=(p, d, q),
                                       seasonal_order=(P, D, Q, s)).fit(disp=-1)

print(best_model.summary())
```

                                     Statespace Model Results                                
    =========================================================================================
    Dep. Variable:                             CLOSE   No. Observations:                  995
    Model:             SARIMAX(0, 1, 0)x(3, 1, 3, 5)   Log Likelihood                 148.874
    Date:                           Tue, 26 Feb 2019   AIC                           -283.748
    Time:                                   13:30:46   BIC                           -249.471
    Sample:                                        0   HQIC                          -270.714
                                               - 995                                         
    Covariance Type:                             opg                                         
    ==============================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------
    ar.S.L5       -0.5663      0.140     -4.036      0.000      -0.841      -0.291
    ar.S.L10      -0.7977      0.143     -5.585      0.000      -1.078      -0.518
    ar.S.L15      -0.0605      0.044     -1.369      0.171      -0.147       0.026
    ma.S.L5       -0.4364      0.135     -3.229      0.001      -0.701      -0.171
    ma.S.L10       0.2804      0.151      1.856      0.063      -0.016       0.576
    ma.S.L15      -0.8079      0.133     -6.095      0.000      -1.068      -0.548
    sigma2         0.0425      0.001     82.840      0.000       0.042       0.044
    ===================================================================================
    Ljung-Box (Q):                       27.34   Jarque-Bera (JB):            597741.80
    Prob(Q):                              0.94   Prob(JB):                         0.00
    Heteroskedasticity (H):               2.78   Skew:                             6.77
    Prob(H) (two-sided):                  0.00   Kurtosis:                       122.68
    ===================================================================================
    
    Warnings:
    [1] Covariance matrix calculated using the outer product of gradients (complex-step).


##### Now, we can predict the closing price of the next five trading days and evaluate the MAPE of the model:


```python
def plot_SARIMA(series, model, n_steps):
    """
        Plot model vs predicted values
        
        series - dataset with time series
        model - fitted SARIMA model
        n_steps - number of steps to predict in the future
    """
    
    data = series.copy().rename(columns = {'CLOSE': 'actual'})
    data['arima_model'] = model.fittedvalues
    #Make a shift on s+d steps, because these values were unobserved by the model due to the differentiating
    data['arima_model'][:s+d] = np.NaN
    
    #Forecast on n_steps forward
    forecast = model.predict(start=data.shape[0], end=data.shape[0] + n_steps)
    forecast = data.arima_model.append(forecast)
    #Calculate error
    error = mean_absolute_percentage_error(data['actual'][s+d:], data['arima_model'][s+d:])
    
    plt.figure(figsize=(17, 8))
    plt.title('Mean Absolute Percentage Error: {0:.2f}%'.format(error))
    plt.plot(forecast, color='r', label='model')
    plt.axvspan(data.index[-1], forecast.index[-1],alpha=0.5, color='lightgrey')
    plt.plot(data, label='actual')
    plt.legend()
    plt.grid(True);

    
# Now, we can predict the closing price of the next five trading days and evaluate the MAPE of the model:
# plot_SARIMA(data, best_model, 5)
print(best_model.predict(start=data.CLOSE.shape[0], end=data.CLOSE.shape[0] + 5))
print(mean_absolute_percentage_error(data.CLOSE[s+d:], best_model.fittedvalues[s+d:]))
```

    995     18.958921
    996     18.966794
    997     18.960400
    998     18.923110
    999     18.943182
    1000    18.921096
    dtype: float64
    0.7853570918549869


In this case, we have a MAPE of 78.5%, which is very good!

#### Now, to compare our prediction with actual data, I took financial data from https://ca.finance.yahoo.com/quote/GF/history?p=GF and created a dataframe:


```python
comparison = pd.DataFrame({'actual': [13.42, 13.49, 13.56, 13.61, 13.38, 13.21],
                          'predicted': [18.96, 18.97, 18.96, 18.92, 18.94, 18.92]}, 
                          index = pd.date_range(start='2019-02-01', periods=6,))
```


```python
comparison.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>actual</th>
      <th>predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2019-02-01</th>
      <td>13.42</td>
      <td>18.96</td>
    </tr>
    <tr>
      <th>2019-02-02</th>
      <td>13.49</td>
      <td>18.97</td>
    </tr>
    <tr>
      <th>2019-02-03</th>
      <td>13.56</td>
      <td>18.96</td>
    </tr>
    <tr>
      <th>2019-02-04</th>
      <td>13.61</td>
      <td>18.92</td>
    </tr>
    <tr>
      <th>2019-02-05</th>
      <td>13.38</td>
      <td>18.94</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.figure(figsize=(17, 8))
plt.plot(comparison.actual)
plt.plot(comparison.predicted)
plt.title('Predicted closing price of New Germany Fund Inc (GF)')
plt.ylabel('Closing price ($)')
plt.xlabel('Trading day')
plt.legend(loc='best')
plt.grid(False)
plt.show()
```


![png](output_49_0.png)


It seems like we are a bit off in our predictions. In fact, we didn't missed an opportunity to make money, since our predictions result in a net gain, whereas the actual closing prices show a net loss. Time to invest, people!


Credit to  Peters Morgan, Edureca Co & Marco Peixeiro for teaching me common techniques to manipulate time series and make predictions.
